﻿namespace GroqSharp
{
    public static class GroqConstants
    {
        public const string DefaultModel = "llama-3.3-70b-versatile";
    }
}
