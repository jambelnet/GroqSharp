﻿// Option 1: Using DocX (requires NuGet package DocX)
using Xceed.Words.NET;

namespace GroqSharp.Utilities
{
    public static class DocxTextExtractor
    {
        public static string ExtractText(string filePath)
        {
            using (var doc = DocX.Load(filePath))
            {
                return doc.Text;
            }
        }
    }
}

// OR Option 2: Using GemBox (more features, requires license for >20 docs)
/*
using GemBox.Document;

namespace GroqSharp.Utilities
{
    public static class DocxTextExtractor
    {
        static DocxTextExtractor()
        {
            ComponentInfo.SetLicense("FREE-LIMITED-KEY");
        }

        public static string ExtractText(string filePath)
        {
            var document = DocumentModel.Load(filePath);
            return document.Content.ToString();
        }
    }
}
*/